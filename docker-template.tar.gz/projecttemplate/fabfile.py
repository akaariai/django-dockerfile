from django_dockerfile.fabfile import *  # noqa
